#Mouse position:
import pyautogui
import time

time.sleep(6)
pyautogui.position()



""" 
(x=482, y=522)
(x=426, y=268)
(x=409, y=864) 
"""